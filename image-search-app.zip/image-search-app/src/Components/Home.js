import { useEffect, useState } from 'react';

export default function Home() {

    const [state, setState] = useState('')
    const [images, setImages] = useState([]);

    const searchHandler = async (e) => {
        setState(e.target.value);
        setImages(() => []);
        // photos/${state}/?client_id={client_id}
        await fetch(`https://api.unsplash.com/photos/?client_id={client-id}&query=${state}`, {
            method: "GET"
        })
            .then(res => res.json())
            .then(res => {
                // console.log(res)
                const data = [];
                res.forEach(img => {
                    //  console.log(img.urls)
                    data.push(img.urls.small);
                })
                // console.log(data);
                setImages(data)
            })

    }

    const clickHandler = async (e) => {
        // setState(e.target.value);
        setImages(() => []);
        // photos/${state}/?client_id={client_id}
        await fetch(`https://api.unsplash.com/photos/?client_id={client-id}&query=${state}`, {
            method: "GET"
        })
            .then(res => res.json())
            .then(res => {
                // console.log(res)
                const data = [];
                res.forEach(img => {
                    //  console.log(img.urls)
                    data.push(img.urls.raw);
                })
                // console.log(data);
                setImages(data)
            })

    }

    return <><div className="container">
        <div className='inner-container'>

            <div className='header-container'>
                <h1>React Photo Search</h1>
                <button>Bookmarks</button>
            </div>

            <div className='search-container'>
                <input type="text" name="search" placeholder='Search for high resolution image' value={state} onChange={searchHandler} />
                <button onClick={clickHandler}>Search</button>
            </div>
        </div>
    </div>
        <div className='grid'>
            {images ? images.map(image => {
                return <img src={image} alt='img' width='200px' />
                // console.log('from map', image)

            }) : ''}
        </div>
    </>
}