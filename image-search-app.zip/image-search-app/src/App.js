import './App.css';
import Home from './Components/Home';
// import {process} from 'react-dotenv';

function App() {
  // console.log('dotenv', process.env);
  return (
    <div className="App">
     <Home/>
    </div>
  );
}

export default App;
